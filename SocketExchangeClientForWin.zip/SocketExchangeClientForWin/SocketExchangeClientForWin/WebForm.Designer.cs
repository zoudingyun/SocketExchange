﻿namespace SocketExchangeClientForWin
{
    partial class WebForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WebForm));
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.small = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.mainLogo = new System.Windows.Forms.NotifyIcon(this.components);
            this.gif = new System.Windows.Forms.Label();
            this.test = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(0, 23);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.ScriptErrorsSuppressed = true;
            this.webBrowser1.ScrollBarsEnabled = false;
            this.webBrowser1.Size = new System.Drawing.Size(1242, 660);
            this.webBrowser1.TabIndex = 1;
            // 
            // small
            // 
            this.small.BackColor = System.Drawing.Color.Transparent;
            this.small.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.small.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.small.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.small.Location = new System.Drawing.Point(1176, 1);
            this.small.Margin = new System.Windows.Forms.Padding(8, 4, 4, 4);
            this.small.Name = "small";
            this.small.Size = new System.Drawing.Size(20, 19);
            this.small.TabIndex = 7;
            this.small.Text = "-";
            this.small.UseVisualStyleBackColor = false;
            this.small.Click += new System.EventHandler(this.Small_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.exit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.exit.Location = new System.Drawing.Point(1208, 1);
            this.exit.Margin = new System.Windows.Forms.Padding(8, 4, 4, 4);
            this.exit.Name = "exit";
            this.exit.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.exit.Size = new System.Drawing.Size(20, 19);
            this.exit.TabIndex = 9;
            this.exit.Text = "×";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // mainLogo
            // 
            this.mainLogo.Icon = ((System.Drawing.Icon)(resources.GetObject("mainLogo.Icon")));
            this.mainLogo.Text = "端口转发控制台";
            this.mainLogo.Visible = true;
            this.mainLogo.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.MainLogo_MouseDoubleClick);
            // 
            // gif
            // 
            this.gif.Image = global::SocketExchangeClientForWin.Properties.Resources._4a067445695b27da8534b90e11f12e7ed2a30cd17c81d_rIgLyn_fw658;
            this.gif.Location = new System.Drawing.Point(433, 144);
            this.gif.Name = "gif";
            this.gif.Size = new System.Drawing.Size(340, 344);
            this.gif.TabIndex = 10;
            // 
            // test
            // 
            this.test.Location = new System.Drawing.Point(1090, -1);
            this.test.Name = "test";
            this.test.Size = new System.Drawing.Size(75, 23);
            this.test.TabIndex = 11;
            this.test.Text = "test";
            this.test.UseVisualStyleBackColor = true;
            this.test.Visible = false;
            this.test.Click += new System.EventHandler(this.test_Click);
            // 
            // WebForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.ClientSize = new System.Drawing.Size(1241, 683);
            this.Controls.Add(this.test);
            this.Controls.Add(this.gif);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.small);
            this.Controls.Add(this.webBrowser1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "WebForm";
            this.Text = "WebForm";
            this.Load += new System.EventHandler(this.WebForm_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button small;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.NotifyIcon mainLogo;
        public System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Label gif;
        private System.Windows.Forms.Button test;
    }
}

