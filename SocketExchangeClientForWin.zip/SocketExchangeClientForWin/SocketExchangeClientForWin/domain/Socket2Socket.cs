﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace SocketExchangeClientForWin.domain
{
    public class Socket2Socket
    {


        /// <summary>
        /// 本地监听线程（监听本地请求并发送建立端口转发申请）
        /// </summary>
        public void localListener1(object obj)
        {
           
                String[] mes = (String[])obj;
                int port = int.Parse(mes[0]);
                String remoteAddress = mes[1];
                TcpListener tl = new TcpListener(port);
                tl.Start();
                while (true)
                {
                    try {
                        TcpClient tc1 = tl.AcceptTcpClient();//这里是等待数据再执行下边，不会100%占用cpu
                        TcpClient tc2 = new TcpClient("127.0.0.1", 10086);

                        object obj1 = (object)(new TcpClient[] { tc1, tc2 });
                        object obj2 = (object)(new TcpClient[] { tc2, tc1 });

                        ThreadPool.QueueUserWorkItem(new WaitCallback(transfer), obj1);
                        ThreadPool.QueueUserWorkItem(new WaitCallback(transfer), obj2);
                    }
                    catch(Exception ex)
                    {

                    }
                }
            

        }


        /// <summary>
        /// 工作子线程高级版（端口转发建立后，实际进行数据转发的线程）
        /// </summary>
        public static void transfer(object obj)
        {
            TcpClient tc1 = ((TcpClient[])obj)[0];
            TcpClient tc2 = ((TcpClient[])obj)[1];
            NetworkStream ns1 = tc1.GetStream();
            NetworkStream ns2 = tc2.GetStream();
            double start = 0;
            double end = 0;
            Boolean overSpeed = false;
            int overSpeedCount = 0;
            while (true)
            {
                start = DateTime.Now.Subtract(DateTime.Parse("1970-1-1")).TotalMilliseconds;
                int count = 0;
                try
                {
                    //这里必须try catch，否则连接一旦中断程序就崩溃了，要是弹出错误提示让机主看见那就囧了
                    byte[] bt = new byte[30720000];
                    count = ns1.Read(bt, 0, bt.Length);
                    ns2.Write(bt, 0, count);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    ns1.Dispose();
                    ns2.Dispose();
                    tc1.Close();
                    tc2.Close();
                    break;
                }
                end = DateTime.Now.Subtract(DateTime.Parse("1970-1-1")).TotalMilliseconds;
                if ((end - start) <= 1 || count == 0)
                {
                    if (overSpeedCount >= 500)
                    {
                        break;//无效线程死循环达到500次自动退出
                    }
                    else
                    {
                        if (!overSpeed)
                        {
                            overSpeed = true;
                            overSpeedCount = 1;
                        }
                        else
                        {
                            overSpeedCount++;
                        }
                    }
                }
            }
            overSpeedCount--;
        }

    }
}
