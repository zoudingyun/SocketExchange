﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using SocketExchangeClientForWin.domain;

namespace SocketExchangeClientForWin
{
    [ComVisible(true)]
    public partial class WebForm : Form
    {

        public String host = "http://127.0.0.1:8848/static/index.html";
        //public String host = "https://echarts.baidu.com/";
        string exename = "SocketExchangeClientForWin.exe";

        public WebForm()
        {
            InitializeComponent();
            webBrowser1.Navigate(host);
            webBrowser1.ObjectForScripting = this;


            string FEATURE_BROWSER_EMULATION = @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION";
            string FEATURE_DOCUMENT_COMPATIBLE_MODE = @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DOCUMENT_COMPATIBLE_MODE";

            string keyName = @"Software\Microsoft\Windows\CurrentVersion\Run";

            using (RegistryKey key1 = Registry.CurrentUser.OpenSubKey(FEATURE_BROWSER_EMULATION, true))
            using (RegistryKey key2 = Registry.CurrentUser.OpenSubKey(FEATURE_DOCUMENT_COMPATIBLE_MODE, true))
            {
                //if (key1 != null) key1.DeleteValue(exename);
                //if (key2 != null) key2.DeleteValue(exename);
                String[] vns1 = key1.GetValueNames();
                String[] vns2 = key2.GetValueNames();
                Boolean flag = false;
                if (vns1.ToList().IndexOf(exename) <0) {
                    key1.SetValue(exename, 10000, RegistryValueKind.DWord);
                    flag = true;
                }
                if (vns2.ToList().IndexOf(exename) < 0) {
                    key2.SetValue(exename, 100000, RegistryValueKind.DWord);
                    flag = true;
                } 
                key1.Close();
                key2.Close();
                if (flag)
                {
                    Application.Restart();
                    System.Environment.Exit(0);
                }
            }

            Socket2Socket socket2Socket = new Socket2Socket();
            object listenPort = (object)(new String[] { 10011 + "", "1:1" });
            ThreadPool.QueueUserWorkItem(new WaitCallback(socket2Socket.localListener1), listenPort);
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确认退出？\n可以点击右上角最小化按钮隐藏到系统托盘！", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void Small_Click(object sender, EventArgs e)
        {
            this.mainLogo.Visible = true;    //显示托盘图标
            this.Hide();    //隐藏窗口
        }

        private void WebForm_Load(object sender, EventArgs e)
        {
            this.MouseDown += new MouseEventHandler(Form1_MouseDown);
            this.MouseMove += new MouseEventHandler(Form1_MouseMove);
            this.MouseUp += new MouseEventHandler(Form1_MouseUp);
        }

        Point mouseOff;//鼠标移动位置变量
        bool leftFlag;//标签是否为左键

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseOff = new Point(-e.X, -e.Y); //得到变量的值
                leftFlag = true;                  //点击左键按下时标注为true;
            }
        }


        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                Point mouseSet = Control.MousePosition;
                mouseSet.Offset(mouseOff.X, mouseOff.Y);  //设置移动后的位置
                Location = mouseSet;
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                leftFlag = false;//释放鼠标后标注为false;
            }
        }

        private void MainLogo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
        }
    }
}
