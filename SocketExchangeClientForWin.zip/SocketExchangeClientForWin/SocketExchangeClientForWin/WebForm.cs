﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using SocketExchangeClientForWin.domain;
using System.Diagnostics;
using System.Net.Sockets;
using System.Net;

namespace SocketExchangeClientForWin
{
    [ComVisible(true)]
    public partial class WebForm : Form
    {

        public String host = "http://127.0.0.1:234";
        public String ipadd = "127.0.0.1";
        public int port = 234;
        //public String host = "https://echarts.baidu.com/";
        string exename = "SocketExchangeClientForWin.exe";
        Process p = new Process();

        public WebForm()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;

            string FEATURE_BROWSER_EMULATION = @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION";
            string FEATURE_DOCUMENT_COMPATIBLE_MODE = @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_DOCUMENT_COMPATIBLE_MODE";

            using (RegistryKey key1 = Registry.CurrentUser.OpenSubKey(FEATURE_BROWSER_EMULATION, true))
            using (RegistryKey key2 = Registry.CurrentUser.OpenSubKey(FEATURE_DOCUMENT_COMPATIBLE_MODE, true))
            {
                if (key1 == null && key2 == null)
                {
                    using (RegistryKey regkey1 = Registry.CurrentUser.CreateSubKey(FEATURE_BROWSER_EMULATION))
                    using (RegistryKey regkey2 = Registry.CurrentUser.CreateSubKey(FEATURE_DOCUMENT_COMPATIBLE_MODE))
                    {
                        regkey1.SetValue(exename, 10000, RegistryValueKind.DWord);
                        regkey2.SetValue(exename, 100000, RegistryValueKind.DWord);
                        regkey1.Close();
                        regkey2.Close();
                    }

                    Application.Restart();
                    System.Environment.Exit(0);
                }
                
            }


            Thread thread1 = new Thread(new ThreadStart(java));
            Thread thread2 = new Thread(new ThreadStart(checkJava));
            //调用Start方法执行线程
            thread1.IsBackground = true;
            thread1.Start();
            thread2.IsBackground = true;
            thread2.Start();

            webBrowser1.IsWebBrowserContextMenuEnabled = false;
            webBrowser1.ObjectForScripting = this;

        }


    private void java()
        {
            try {
            //Console.WriteLine("请输入要执行的命令:");
            string strInput = @"SeJar\bin\java.exe -jar .\SeJar\bin\socket-exchange-client-cp-0.0.1-SNAPSHOT.jar";
            //Process p = new Process();
            //设置要启动的应用程序
            p.StartInfo.FileName = "cmd.exe";
            //是否使用操作系统shell启动
            p.StartInfo.UseShellExecute = false;
            // 接受来自调用程序的输入信息
            p.StartInfo.RedirectStandardInput = true;
            //输出信息
            p.StartInfo.RedirectStandardOutput = true;
            // 输出错误
            p.StartInfo.RedirectStandardError = true;
            //不显示程序窗口
            p.StartInfo.CreateNoWindow = true;
            //启动程序
            p.Start();
            //向cmd窗口发送输入信息
            p.StandardInput.WriteLine(strInput + "&exit");
            p.StandardInput.AutoFlush = true;

            string strOuput = p.StandardOutput.ReadToEnd();
            p.StandardInput.WriteLine("&exit");
            p.Close();
            }
            catch (Exception ex)
            {
                p.Close();
                System.Environment.Exit(0);
            }
        }



        private void checkJava()
        {

            IPAddress ip = IPAddress.Parse(ipadd);
            Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            
            while (true)
            {
                try {
                    clientSocket.Connect(new IPEndPoint(ip, port));
                    gif.Visible = false;
                    webBrowser1.Navigate(host);
                    
                    
                    break;
                }
                catch(Exception ex)
                {
                    Thread.Sleep(500);
                    continue;
                }
            }


        }

        private void Exit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确认退出？\n可以点击右上角最小化按钮隐藏到系统托盘！", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                webBrowser1.Document.InvokeScript("appClose");
                Application.Exit();
            }
        }

        private void Small_Click(object sender, EventArgs e)
        {
            this.mainLogo.Visible = true;    //显示托盘图标
            this.Hide();    //隐藏窗口
        }

        private void WebForm_Load(object sender, EventArgs e)
        {
            this.MouseDown += new MouseEventHandler(Form1_MouseDown);
            this.MouseMove += new MouseEventHandler(Form1_MouseMove);
            this.MouseUp += new MouseEventHandler(Form1_MouseUp);
        }

        Point mouseOff;//鼠标移动位置变量
        bool leftFlag;//标签是否为左键

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseOff = new Point(-e.X, -e.Y); //得到变量的值
                leftFlag = true;                  //点击左键按下时标注为true;
            }
        }


        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                Point mouseSet = Control.MousePosition;
                mouseSet.Offset(mouseOff.X, mouseOff.Y);  //设置移动后的位置
                Location = mouseSet;
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (leftFlag)
            {
                leftFlag = false;//释放鼠标后标注为false;
            }
        }

        private void MainLogo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
        }

        private void test_Click(object sender, EventArgs e)
        {
            webBrowser1.Document.InvokeScript("appClose");
        }
    }
}
